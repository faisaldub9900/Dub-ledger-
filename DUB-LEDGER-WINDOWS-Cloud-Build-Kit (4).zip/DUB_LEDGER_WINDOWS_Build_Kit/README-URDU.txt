DUB LEDGER WINDOWS 1.0 — Build Kit

اہم: یہ ZIP مکمل ISO نہیں بلکہ ISO بنانے کا build project ہے۔ یہاں Debian package repositories تک نیٹ ورک رسائی دستیاب نہ ہونے کی وجہ سے ISO compile نہیں ہو سکی۔

بنیاد: Debian 13 (Trixie) + XFCE، 64-bit amd64۔ اس میں Firefox ESR (ابتدائی براؤزر)، NetworkManager، Bluetooth Manager، VLC اور عام Intel/Realtek/Broadcom/Atheros firmware پیکجز شامل ہیں۔ اصل Wi-Fi/Bluetooth سپورٹ مخصوص hardware/driver پر منحصر ہے۔ Landline/dial-up modem کے لیے اس کے chipset کا driver درکار ہوگا۔

ISO بنانے کے مراحل:
1) 64-bit Debian 13 یا compatible Debian/Ubuntu Linux PC پر ZIP extract کریں۔
2) انٹرنیٹ اور کم از کم 20GB خالی جگہ رکھیں؛ build کئی GB ڈاؤن لوڈ کرے گا۔
3) Terminal میں اس فولڈر میں جا کر چلائیں: sudo ./BUILD-LINUX.sh
4) مکمل ہونے پر DUB-LEDGER-WINDOWS-1.0-amd64.iso اسی فولڈر میں ہوگی۔
5) انسٹالیشن کے بعد اصل Google Chrome لگانے کے لیے اس فولڈر میں جا کر چلائیں: sudo bash scripts/install-google-chrome.sh ۔ یہ Google کے آفیشل ریپوزٹری سے Chrome ڈاؤن لوڈ اور انسٹال کرے گا؛ Chrome ISO میں پہلے سے شامل نہیں ہے۔
6) Rufus میں USB منتخب کریں، ISO منتخب کریں اور Start دبائیں۔ USB کا تمام ڈیٹا مٹ جائے گا۔ پہلے Live USB سے Wi-Fi، آواز، Bluetooth اور گرافکس ٹیسٹ کریں، پھر انسٹال کریں۔

احتیاط: انسٹال کرنے سے پہلے backup لازمی بنائیں۔ UEFI کمپیوٹر پر GPT/UEFI اور Legacy BIOS پر MBR/BIOS منتخب کریں۔ نام میں Windows صرف branding ہے؛ یہ Microsoft Windows نہیں بلکہ Debian Linux XFCE پر مبنی سسٹم ہے، اس لیے Windows کے تمام پروگرام براہِ راست نہیں چلیں گے۔ یہ ابتدائی build ہے؛ hardware testing کے بعد ہی روزمرہ استعمال کریں۔

موبائل سے Cloud Build:
نئے README-CLOUD-BUILD-URDU.txt میں GitHub Actions کے ذریعے cloud پر ISO بنانے کے مراحل دیے گئے ہیں۔ یہ build کوشش ہے، کامیابی کی ضمانت نہیں؛ ناکامی کی صورت میں GitHub Actions logs دیکھیں۔
