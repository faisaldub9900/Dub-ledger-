#!/bin/bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then
  echo "Run as administrator: sudo bash scripts/install-google-chrome.sh" >&2
  exit 1
fi
if ! command -v apt-get >/dev/null 2>&1; then
  echo "This installer is intended for Debian-based DUB LEDGER WINDOWS." >&2
  exit 1
fi
apt-get update
apt-get install -y ca-certificates curl
install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://dl.google.com/linux/linux_signing_key.pub -o /etc/apt/keyrings/google-chrome.asc
chmod 0644 /etc/apt/keyrings/google-chrome.asc
cat > /etc/apt/sources.list.d/google-chrome.list <<'REPO'
deb [arch=amd64 signed-by=/etc/apt/keyrings/google-chrome.asc] https://dl.google.com/linux/chrome/deb/ stable main
REPO
apt-get update
apt-get install -y google-chrome-stable
printf '\nGoogle Chrome installed. Launch it from the Internet menu or run: google-chrome-stable\n'
