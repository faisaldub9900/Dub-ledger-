#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ]; then echo "Run with sudo: sudo ./BUILD-LINUX.sh" >&2; exit 1; fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y live-build debootstrap squashfs-tools xorriso isolinux syslinux-common grub-pc-bin grub-efi-amd64-bin mtools dosfstools
lb clean --purge || true
./auto/config
lb build
OUT=$(find . -maxdepth 1 -type f -name '*.iso' -print -quit)
if [ -z "$OUT" ]; then echo "Build finished but ISO was not found." >&2; exit 2; fi
cp "$OUT" ./DUB-LEDGER-WINDOWS-1.0-amd64.iso
sha256sum ./DUB-LEDGER-WINDOWS-1.0-amd64.iso > ./DUB-LEDGER-WINDOWS-1.0-amd64.iso.sha256
echo "Created $PWD/DUB-LEDGER-WINDOWS-1.0-amd64.iso"
