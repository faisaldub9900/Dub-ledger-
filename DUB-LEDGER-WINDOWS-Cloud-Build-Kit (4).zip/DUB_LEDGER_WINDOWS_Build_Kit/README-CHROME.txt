اصل Google Chrome کے بارے میں

اس build kit میں Google Chrome کا installer script شامل ہے:
scripts/install-google-chrome.sh

DUB LEDGER WINDOWS انسٹال کرنے کے بعد ZIP فولڈر کھولیں، scripts فولڈر میں جائیں اور Terminal میں چلائیں:
sudo bash install-google-chrome.sh

یہ Google کی آفیشل signing key اور apt repository استعمال کرکے google-chrome-stable انسٹال کرتا ہے۔ Chrome خود ISO میں شامل نہیں، کیونکہ اسے build کے وقت Google سے ڈاؤن لوڈ کرنا ہوگا۔

نوٹ: YouTube کی ویڈیوز دیکھنے کے لیے Chrome میں YouTube کھولیں۔ ویڈیو ڈاؤن لوڈ صرف YouTube کی اجازت یافتہ آف لائن سہولت یا مواد کے مالک کی اجازت کے مطابق کریں۔
