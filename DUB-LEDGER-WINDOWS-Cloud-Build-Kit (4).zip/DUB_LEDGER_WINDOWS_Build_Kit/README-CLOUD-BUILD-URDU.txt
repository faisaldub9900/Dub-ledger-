DUB LEDGER WINDOWS 1.0 — موبائل سے Cloud Build

یہ Build Kit خود ISO نہیں ہے۔ اس میں GitHub Actions کا workflow شامل ہے تاکہ GitHub کے cloud runner پر ISO بنانے کی کوشش کی جا سکے۔ Build کامیاب ہونے کی ضمانت نہیں؛ پہلی build میں package، installer یا boot configuration کی خرابی سامنے آ سکتی ہے۔

ضروری چیزیں:
- GitHub اکاؤنٹ
- موبائل براؤزر اور انٹرنیٹ
- GitHub پر نیا repository بنائیں (مثلاً dub-ledger-windows)

موبائل سے طریقہ:
1. ZIP کو Extract کریں۔
2. GitHub.com پر sign in کریں اور New repository بنائیں۔
3. Extract کیے گئے فولڈر کے اندر کی تمام فائلیں اور فولڈرز repository کی root میں upload کریں۔ صرف outer folder upload نہ کریں۔
4. تصدیق کریں کہ repository میں .github/workflows/build-iso.yml موجود ہے۔ موبائل پر hidden .github فولڈر نظر نہ آئے تو GitHub ویب سائٹ میں Add file > Create new file استعمال کریں اور نام .github/workflows/build-iso.yml رکھ کر workflow کا متن paste کریں۔
5. Repository کے Actions tab میں جائیں۔ اگر GitHub workflow چلانے کی اجازت مانگے تو اسے enable کریں۔
6. بائیں طرف “Build DUB LEDGER WINDOWS ISO” منتخب کریں، پھر “Run workflow” دبائیں۔
7. Build مکمل ہونے کا انتظار کریں۔ کامیابی پر اسی run کے نیچے Artifacts میں “DUB-LEDGER-WINDOWS-1.0-amd64-ISO” ZIP ڈاؤن لوڈ کریں۔ اسے Extract کرنے پر ISO اور SHA256 checksum ملیں گے۔

اہم:
- GitHub runner پر build ناکام بھی ہو سکتی ہے؛ ناکامی پر Actions کے logs کا screenshot شیئر کریں۔
- Cloud build کے لیے GitHub کی موجودہ usage limits اور account policy لاگو ہوں گی۔
- اصل Google Chrome اس ISO میں شامل نہیں؛ Debian انسٹال ہونے کے بعد scripts/install-google-chrome.sh چلانے سے Google کے آفیشل repository سے انسٹال کیا جا سکتا ہے۔
- YouTube براؤزر میں چلے گا۔ ہر ویڈیو کی فائل ڈاؤن لوڈنگ کی ضمانت نہیں؛ صرف مجاز/آفیشل offline/download طریقے استعمال کریں۔
- ISO کو انسٹال کرنے سے پہلے Live USB میں hardware test کریں اور اپنے کمپیوٹر کے ڈیٹا کا backup بنائیں۔
- یہ Debian Linux XFCE پر مبنی نظام ہے، Microsoft Windows نہیں۔
